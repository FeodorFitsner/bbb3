$files = @{
    "nodejs" = "c:\Program Files (x86)\nodejs"
}
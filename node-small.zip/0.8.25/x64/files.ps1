$files = @{
    "nodejs" = "c:\Program Files\nodejs"
}